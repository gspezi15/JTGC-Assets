function onNPCKill(eventObj, killedNPC, killReason)
	if killedNPC.id == 400 then
		for i = -1,1 do
			if i ~= 0 then
				local debris1 = Animation.spawn(761,killedNPC.x,killedNPC.y)
				debris1.speedX = 2*i
				debris1.speedY = -4
			end
		end
		Animation.spawn(760,killedNPC.x,killedNPC.y)
		Animation.spawn(763,killedNPC.x,killedNPC.y)
		SFX.play("Save_barrel.wav")
	end
end