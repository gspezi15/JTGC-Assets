--NPCManager is required for setting basic NPC properties
local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

--Create the library table
local ball = {}
--NPC_ID is dynamic based on the name of the library file
local npcID = NPC_ID

--Defines NPC config for our NPC. You can remove superfluous definitions.
local ballSettings = {
	id = npcID,
	--Sprite size
	gfxheight = 32,
	gfxwidth = 32,
	--Hitbox size. Bottom-center-bound to sprite size.
	width = 32,
	height = 32,
	--Sprite offset from hitbox for adjusting hitbox anchor on sprite.
	gfxoffsetx = 0,
	gfxoffsety = 0,
	--Frameloop-related
	frames = 5,
	framestyle = 0,
	framespeed = 8, --# frames between frame change
	--Movement speed. Only affects speedX by default.
	speed = 1,
	--Collision-related
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt=true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi= true,
	nowaterphysics = false,
	--Various interactions
	jumphurt = true, --If true, spiny-like
	spinjumpsafe = false, --If true, prevents player hurt when spinjumping
	harmlessgrab = false, --Held NPC hurts other NPCs if false
	harmlessthrown = false, --Thrown NPC hurts other NPCs if false

	grabside=false,
	grabtop=false,

	--Define custom properties below
}

--Applies NPC settings
npcManager.setNpcSettings(ballSettings)

local fire = Misc.resolveSoundFile("SM64 Fireball")

--Register events
function ball.onInitAPI()
	npcManager.registerEvent(npcID, ball, "onTickNPC")
end

function ball.onTickNPC(v)
	--Don't act during time freeze
	if Defines.levelFreeze then return end
	
	local data = v.data
	local settings = v.data._settings
	
	--If despawned
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		--Reset our properties, if necessary
		data.initialized = false
			if settings.delay >= 162 then
				data.countTimer = settings.delay - 128
			else
				data.countTimer = settings.delay - 25
			end
		return
	end

	--Initialize
	if not data.initialized then
		--Initialize necessary data.
		data.initialized = true
		if settings.delay == nil then
			settings.delay = 383
		end
		if settings.delay >= 162 then
			data.countTimer = settings.delay - 128
		else
			data.countTimer = settings.delay - 25
		end
	end

	--Depending on the NPC, these checks must be handled differently
	if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then
		--Handling
	end
	
	v.animationTimer = 0
	if v.underwater == true then
		if settings.delay >= 162 then
			data.countTimer = settings.delay - 128
		else
			data.countTimer = settings.delay - 25
		end
	else
		data.countTimer = data.countTimer + 1
		
			if data.countTimer >= settings.delay - 25 and data.countTimer <= settings.delay - 17 then
				v.animationFrame = 1
			elseif data.countTimer >= settings.delay - 20 and data.countTimer <= settings.delay - 8 then
				v.animationFrame = 2
			elseif data.countTimer >= 0 and data.countTimer <= 25 and settings.delay >= 25 then
				v.animationFrame = 4
			elseif data.countTimer > 25 and data.countTimer <= 33 and settings.delay >= 25 then
				v.animationFrame = 3
			else
				v.animationFrame = 0
			end
			
		if data.countTimer >= settings.delay then
			SFX.play(fire)
			if v.direction == 1 then
				NPC.spawn(752, v.x + 1.1 * v.width, v.y + 0 * v.height + 8, player.section, false, true)
			else
				NPC.spawn(752, v.x + -0.1 * v.width, v.y + 0 * v.height + 8, player.section, false, true)
			end
			data.countTimer = 0
		end
	end
	npcutils.faceNearestPlayer(v)
end

--Gotta return the library table!
return ball